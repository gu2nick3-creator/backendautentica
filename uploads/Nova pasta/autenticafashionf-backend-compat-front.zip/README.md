# Autentica Fashionf Backend

Backend em PHP + MySQL compatível com o frontend refatorado que consome `src/services/*`.

## Endpoints compatíveis

### Auth
- `POST /api/auth/login`
- `POST /api/auth/register`
- `GET /api/auth/me`
- `POST /api/auth/logout`

### Cliente
- `GET /api/customers/me`
- `PUT /api/customers/me`

### Loja
- `GET /api/categories`
- `GET /api/products`
- `GET /api/products/{id}`
- `POST /api/coupons/validate`
- `GET /api/orders/my`
- `POST /api/orders`

### Admin
- `GET /api/admin/dashboard`
- `GET /api/admin/products`
- `POST /api/admin/products`
- `PUT /api/admin/products/{id}`
- `DELETE /api/admin/products/{id}`
- `GET /api/admin/categories`
- `POST /api/admin/categories`
- `PUT /api/admin/categories/{id}`
- `DELETE /api/admin/categories/{id}`
- `GET /api/admin/customers`
- `GET /api/admin/orders`
- `PUT /api/admin/orders/{id}/status`
- `PUT /api/admin/orders/{id}/tracking`
- `GET /api/admin/coupons`
- `POST /api/admin/coupons`
- `PUT /api/admin/coupons/{id}`
- `DELETE /api/admin/coupons/{id}`
- `POST /api/admin/uploads`

## Importante
As respostas retornam JSON direto, no formato que o frontend espera.

Exemplos:
- login/register: `{ "user": {...}, "token": "..." }`
- `GET /api/products`: `[...]`
- `POST /api/coupons/validate`: `{ "valid": true, "coupon": {...} }`
- upload: `{ "url": "https://.../uploads/arquivo.jpg" }`

## Como subir
1. Copie `.env.example` para `.env`
2. Importe `database/schema.sql`
3. Opcionalmente importe `database/seed.sql`
4. Aponte o domínio/subdomínio do backend para a pasta `public/`
5. No frontend, configure `VITE_API_URL` com a URL base do backend

## Credenciais padrão do admin
- email: valor de `ADMIN_EMAIL`
- senha: valor de `ADMIN_PASSWORD`
